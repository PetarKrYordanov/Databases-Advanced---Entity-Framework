namespace Stations.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=DESKTOP-PSI12NO\SQLEXPRESS;Database=Stations;Trusted_Connection=True";
	}
}