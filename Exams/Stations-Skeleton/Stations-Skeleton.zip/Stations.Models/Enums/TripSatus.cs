﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Stations.Models.Enums
{
    public enum TripSatus
    {
        OnTime,Delayed , Early 
    }
}
