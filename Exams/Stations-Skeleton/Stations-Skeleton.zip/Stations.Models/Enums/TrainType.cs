﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Stations.Models.Enums
{
    public enum TrainType
    {
        HighSpeed,LongDistance,Freight
    }
}
